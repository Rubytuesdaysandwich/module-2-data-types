<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Data-types part 3</title>
  </head>
  <body>
  <ul>
        <h1 class="php-header">PHP DATA TYPES</h1>
        <li>
        <a href="basic.html">Home</a>
        </li>
        <li>
          <a href="data_types_part1.php">part1</a>
        </li>
        <li>
          <a href="data_types_part2.php">part2</a>
        </li>
        <li>
          <a href="#">part3</a>
        </li>
        <li>
          <a href="data_types_part4.php">part4</a>
        </li>
        
      </ul>
<!--original:--><?php $variable = 8 ;  echo "value is now {$variable}";//original value starting point?><br/>
<!--add 2:--><?php $variable += 2; echo "value is now {$variable}";//solves for in place addition short version for concat?><br/>
<!--subtract 4:--><?php $variable -= 4; echo "value is now {$variable}";//solves for in place subtraction short version for concat?><br/>
<!--multiply 5:--><?php $variable *= 5; echo "value is now {$variable}";//solves for in place multiplication short version for concat?><br/>
<!--divide 3:--><?php $variable /= 3; echo "value is now {$variable}";//solves for in place divide short version for concat?><br/>
<br/>
<!--increment:--><?php $variable ++; echo "value is now {$variable}";//incrementing by 1?><br/>
<!--decrement:--><?php $variable --; echo "value is now {$variable}";//decrementing by 1?><br/>
<br/>
  </body>
</html>
