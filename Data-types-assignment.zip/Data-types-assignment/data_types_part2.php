<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Data types part 2</title>
  </head>
  <body>
  <ul>
        <h1 class="php-header">PHP DATA TYPES</h1>
        <li>
        <a href="basic.html">Home</a>
        </li>
        <li>
          <a href="data_types_part1.php">part1</a>
        </li>
        <li>
          <a href="#">part2</a>
        </li>
        <li>
          <a href="data_types_part3.php">part3</a>
        </li>
        <li>
          <a href="data_types_part4.php">part4</a>
        </li>
        
      </ul>
    <?php
    $x=10;//assigning x to 10 and y to 7
    $y=7;
    ?>

    <?php echo $x + $y;//math add?><br/>
    <?php echo $x - $y;//math subtract?><br/>
    <?php echo $x * $y;//math multiply?><br/>
    <?php echo $x / $y;//math divide?><br/>
    <?php echo $x % $y;//math percentage?><br/>



  </body>
</html>
