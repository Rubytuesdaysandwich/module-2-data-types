<!DOCTYPE html>
<html lang="en">
  <head>
    <title>data-types assignment</title>
  </head>
  <body>
  <header>
      <ul>
        <h1 class="php-header">PHP DATA TYPES</h1>
        <li>
        <a href="basic.html">Home</a>
        </li>
        <li>
          <a href="#">part1</a>
        </li>
        <li>
          <a href="data_types_part2.php">part2</a>
        </li>
        <li>
          <a href="data_types_part3.php">part3</a>
        </li>
        <li>
          <a href="data_types_part4.php">part4</a>
        </li>
        
      </ul>
    </header>
    1. <?php echo"Twinkle, Twinkle little star";//sends the string to the browser?><br/>

    2. <?php 
    $twinkle1 = "Twinkle";
    $twinkle2 = "star";
    //giving each variable a assignment
    ?><br/>

    3. <?php echo "{$twinkle1},{$twinkle1} little {$twinkle2}";//sending the text to the browser and the variable are being used in place of text?><br/>

    4.<?php
    $twinkle1 = "red" ;
    $twinkle2 = "rocket-ship";
    //giving each variable an assignment
    ?><br/>

    5.<?php echo "{$twinkle1},{$twinkle1} little {$twinkle2}";//sending the text to the browser and the variable are being used in place of text?><br/>


  </body>
</html>
